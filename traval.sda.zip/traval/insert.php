<!DOCTYPE html>
<html>



<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<style type="text/css">
    .register{
    background: -webkit-linear-gradient(left, #3931af, #00c6ff);
    margin-top: 0%;
    padding: 3%;
}
.register-left{
    text-align: center;
    color: #fff;
    margin-top: 4%;
}
.register-left input{
    border: none;
    border-radius: 1.5rem;
    padding: 2%;
    width: 100%;
    background: #f8f9fa;
    font-weight: bold;
    color: #383d41;
    margin-top: 30%;
    margin-bottom: 3%;
    cursor: pointer;
}
.register-right{
    background: #f8f9fa;
    border-top-left-radius: 10% 50%;
    border-bottom-left-radius: 10% 50%;
}
.register-left img{
    margin-top: 15%;
    margin-bottom: 5%;
    width: 25%;
    -webkit-animation: mover 2s infinite  alternate;
    animation: mover 1s infinite  alternate;
}
@-webkit-keyframes mover {
    0% { transform: translateY(0); }
    100% { transform: translateY(-20px); }
}
@keyframes mover {
    0% { transform: translateY(0); }
    100% { transform: translateY(-20px); }
}
.register-left p{
    font-weight: lighter;
    padding: 12%;
    margin-top: -9%;
}
.register .register-form{
    padding: 10%;
    margin-top: 10%;
}
.btnRegister{
    float: right;
    margin-top: 10%;
    border: none;
    border-radius: 1.5rem;
    padding: 2%;
    background: #0062cc;
    color: #fff;
    font-weight: 600;
    width: 50%;
    cursor: pointer;
}
.register .nav-tabs{
    margin-top: 3%;
    border: none;
    background: #0062cc;
    border-radius: 1.5rem;
    width: 28%;
    float: right;
}
.register .nav-tabs .nav-link{
    padding: 2%;
    height: 34px;
    font-weight: 600;
    color: #fff;
    border-top-right-radius: 1.5rem;
    border-bottom-right-radius: 1.5rem;
}
.register .nav-tabs .nav-link:hover{
    border: none;
}
.register .nav-tabs .nav-link.active{
    width: 100px;
    color: #0062cc;
    border: 2px solid #0062cc;
    border-top-left-radius: 1.5rem;
    border-bottom-left-radius: 1.5rem;
}
.register-heading{
    text-align: center;
    margin-top: 8%;
    margin-bottom: -15%;
    color: #495057;
}
</style>


  <body>

<div class="container-fluid register">
                <div class="row">
                    <div class="col-md-3 register-left">
                        <img src="logo.png" alt=""/>
                        <h3>Welcome</h3>
                        <p>SMAT Air lines  "Traveling the globe, making dreams come true."</p>
<!--                         <input type="submit" onclick="myFunction(retrieve.php)" name="" value="Bookings" /><br/>
 -->
 <input type="submit" value="Bookings"     onclick="window.location='retrieve.php';" />  
  <input type="submit" value="Remove Booking"  style="margin-top: 1px!important;"    onclick="window.location='delete.php';" />  

                    </div>

                    <div class="col-md-9 register-right">
                       <!--  <ul class="nav nav-tabs nav-justified" id="myTab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Employee</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Hirer</a>
                            </li>
                        </ul> -->
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                <h3 class="register-heading">Apply now to making dreams come true</h3>
                                <div class="row register-form">
                                    <div class="col-md-12">
                                          <form method="post" action="process.php">
                                        <div class="form-group">
<!--                                             <input type="text" class="form-control" placeholder="First Name *" value="" />
 -->                                                    <input type="text" name="name"class="form-control" placeholder=" Name *" value="" >

                                        </div>
                                        <div class="form-group">
<!--                                             <input type="text" class="form-control" placeholder="Last Name *" value="" />
 -->                                                    <input type="text" name="email"  class="form-control" placeholder="Email *" value="">

                                        </div>
                                        <div class="form-group">
<!--                                             <input type="password" class="form-control" placeholder="Password *" value="" />
 -->                                                    <input type="number" name="phone" class="form-control" placeholder="Number *" value="" >

                                        </div>
                                        <div class="form-group">
<!--                                             <input type="password" class="form-control"  placeholder="Confirm Password *" value="" />
 -->                                                    <input type="date" name="date" class="form-control"  placeholder="Date *" value="" >

                                        </div>
                                         <div class="form-group">
<!--                                             <input type="password" class="form-control"  placeholder="Confirm Password *" value="" />
 -->                                                         <input type="text" name="t_from" class="form-control"  placeholder="Traval From *" value="" >

                                        </div>
                                         <div class="form-group">
                                            <!-- <input type="password" class="form-control"  placeholder="Confirm Password *" value="" /> -->
                                                    <input type="text" name="t_to" class="form-control"  placeholder="Traval To  *" value="">

                                        </div>
                                             <div class="form-group">
                                            <!-- <input type="password" class="form-control"  placeholder="Confirm Password *" value="" /> -->
                                            <input type="number" name="amount" class="form-control"  placeholder="Amount *" value="">

                                        </div>

                                        <div class="form-group">
                                            <div class="maxl">
                                                <label class="radio inline"> 
                                                    <input type="radio" name="gender" value="male" checked>
                                                    <span> Male </span> 
                                                </label>
                                                <label class="radio inline"> 
                                                    <input type="radio" name="gender" value="female">
                                                    <span>Female </span> 
                                                </label>
                                                                                                                                  <input type="submit" class="btnRegister" name="save" value="submit"/>

                                            </div>

                                        </div>  



                                    </div>
                                    </form>
                                </div>
                            </div>
                        
                        </div>
                    </div>
                </div>

            </div>
  </body>
</html>

